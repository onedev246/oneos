
clear
echo wellcome
read -p "choose app or directory: " pil
if [ $pil = "1" ]
then
    apt update
    clear
    bash os.sh
elif [ $pil = "2" ]
then
     echo one.os is shutting down
elif [ $pil = "3" ]
then
    clear
    echo terminal
else
    echo no app or directory
fi